.. coni documentation master file, created by
   sphinx-quickstart on Sat Nov 18 09:45:34 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to ansible-otc documentation!
=====================================

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   intro
   connect
   workshop
   buildservice
   dns
   roles

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
